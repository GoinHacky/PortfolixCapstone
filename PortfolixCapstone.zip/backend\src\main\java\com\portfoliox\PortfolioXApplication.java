package com.portfoliox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioXApplication {
    public static void main(String[] args) {
        SpringApplication.run(PortfolioXApplication.class, args);
    }
} 